#include "SDL/SDL.h"
#include <iostream>
using namespace std;

const int WIDTH = 800;
const int HEIGHT = 600;

int main(int argc, char* args[])
{
	SDL_Window* window = nullptr;
	SDL_Surface* screenSurface = nullptr;
	SDL_Surface* letterSurface = nullptr;
	SDL_Surface* keySurface[5];

	if (SDL_Init(SDL_INIT_VIDEO) < 0)
	{
		cout << "SDL_Init failed, Error: " << SDL_GetError() << endl;
	}
	else
	{
		keySurface[0] = SDL_LoadBMP("select.bmp");
		keySurface[1] = SDL_LoadBMP("a.bmp");
		keySurface[2] = SDL_LoadBMP("b.bmp");
		keySurface[3] = SDL_LoadBMP("c.bmp");
		keySurface[4] = SDL_LoadBMP("d.bmp");


		window = SDL_CreateWindow("Lab 1", 100, 100, WIDTH, HEIGHT, 0);

		if (window == nullptr)
		{
			cout << "SDL_CreateWindow failed, Error: " << SDL_GetError() << endl;
		}
		else
		{
			screenSurface = SDL_GetWindowSurface(window);
			letterSurface = keySurface[0];

			if (letterSurface == nullptr)
			{
				cout << "I couldn't open the file" << endl;
			}
			else
			{
				bool done = false;
				SDL_Event event;

				while (!done)
				{
					while (SDL_PollEvent(&event) != 0)
					{
						if (event.type == SDL_KEYDOWN)
						{
							if (event.key.keysym.sym == SDLK_a)
							{
								letterSurface = keySurface[1];
							}
							else if (event.key.keysym.sym == SDLK_b)
							{
								letterSurface = keySurface[2];
							}
							else if (event.key.keysym.sym == SDLK_c)
							{
								letterSurface = keySurface[3];
							}
							else if (event.key.keysym.sym == SDLK_d)
							{
								letterSurface = keySurface[4];
							}
							else 
							{
								letterSurface = keySurface[0];
							}

							if (event.key.keysym.sym == SDLK_0)
							{
								done = true;
							}
						}
					}

					SDL_BlitSurface(letterSurface, NULL, screenSurface, NULL);
					SDL_UpdateWindowSurface(window);
				}
			}
		}
	}
	SDL_FreeSurface(letterSurface);
	letterSurface = nullptr;
	SDL_FreeSurface(screenSurface);
	screenSurface = nullptr;
	SDL_DestroyWindow(window);
	window = nullptr;
	SDL_Quit();

	return 0;
}
