#include "SDL/SDL.h"
#include <iostream>
using namespace std;

const int WIDTH = 800;
const int HEIGHT = 600;

int main(int argc, char* args[])
{
	SDL_Window* window = nullptr;
	SDL_Surface* screenSurface = nullptr;
	SDL_Surface* letterSurface = nullptr;

	if (SDL_Init(SDL_INIT_VIDEO) < 0)
	{
		cout << "SDL_Init failed, Error: " << SDL_GetError() << endl;
	}
	else
	{
		window = SDL_CreateWindow("Lab 1", 100, 100, WIDTH, HEIGHT, 0);

		if (window == nullptr)
		{
			cout << "SDL_CreateWindow failed, Error: " << SDL_GetError() << endl;
		}
		else
		{
			screenSurface = SDL_GetWindowSurface(window);
			letterSurface = SDL_LoadBMP("select.bmp");

			if (letterSurface == nullptr)
			{
				cout << "I couldn't open the file" << endl;
			}
			else
			{
				bool done = false;
				SDL_Event event;

				while (!done)
				{
					while (SDL_PollEvent(&event) != 0)
					{
						if (event.type == SDL_KEYDOWN)
						{
							if (event.key.keysym.sym == SDLK_a)
							{
								letterSurface = SDL_LoadBMP("a.bmp");
							}
							else if (event.key.keysym.sym == SDLK_b)
							{
								letterSurface = SDL_LoadBMP("b.bmp");
							}
							else if (event.key.keysym.sym == SDLK_c)
							{
								letterSurface = SDL_LoadBMP("c.bmp");
							}
							else if (event.key.keysym.sym == SDLK_d)
							{
								letterSurface = SDL_LoadBMP("d.bmp");
							}
							else if (event.key.keysym.sym == SDLK_0)
							{
								done = true;
							}
						}
					}

					SDL_BlitSurface(letterSurface, NULL, screenSurface, NULL);
					SDL_UpdateWindowSurface(window);
				}
			}
		}
	}
	SDL_FreeSurface(letterSurface);
	letterSurface = nullptr;
	SDL_FreeSurface(screenSurface);
	screenSurface = nullptr;
	SDL_DestroyWindow(window);
	window = nullptr;
	SDL_Quit();

	return 0;
}
